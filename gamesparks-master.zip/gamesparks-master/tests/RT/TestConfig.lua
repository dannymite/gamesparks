TestConfig = {}
TestConfig.mFinished = false
TestConfig.apiKey = "q353968tYbEs"
TestConfig.secret = "MVdxVkZuRG1SbXdvVVBBMw=="
TestConfig.rtServer = "gst-men-rt02.gamesparks.net"
TestConfig.cluster = "gst-aeu000"
TestConfig.port = 5050
TestConfig.version = 1560375279
   
return TestConfig